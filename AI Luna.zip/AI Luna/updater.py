import os
import sys
import zipfile
import requests
import subprocess

# ==== НАСТРОЙКИ ====
GITHUB_RELEASE_URL = "https://github.com/kileshift1-lang/AI-LUna/releases/download/Luna/AI.Luna.zip"
REMOTE_VERSION_URL = "https://raw.githubusercontent.com/kileshift1-lang/AI-LUna/refs/heads/main/version.txt"

VERSION_FILE = "version.txt"
TEMP_ZIP = "update_temp.zip"
PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))


def get_local_version():
    if not os.path.exists(VERSION_FILE):
        return "0.0.0"
    with open(VERSION_FILE, "r", encoding="utf-8") as f:
        return f.read().strip()


def get_remote_version():
    try:
        response = requests.get(REMOTE_VERSION_URL, timeout=10)
        response.raise_for_status()
        return response.text.strip()
    except Exception as e:
        print("⚠️ Не удалось получить версию с GitHub:", e)
        return None


def download_update():
    print("⬇️ Скачивание обновления...")
    response = requests.get(GITHUB_RELEASE_URL, stream=True)
    response.raise_for_status()
    with open(TEMP_ZIP, "wb") as f:
        for chunk in response.iter_content(chunk_size=8192):
            f.write(chunk)
    print("✅ Обновление скачано.")


def install_update():
    print("📦 Распаковка обновления...")
    with zipfile.ZipFile(TEMP_ZIP, "r") as zip_ref:
        zip_ref.extractall(PROJECT_DIR)
    os.remove(TEMP_ZIP)
    print("✅ Файлы обновлены.")


def restart_main():
    print("🔄 Перезапуск программы...")
    python = sys.executable
    subprocess.Popen([python, "main.py"])
    sys.exit(0)


def main():
    print("🔍 Проверка обновлений...")

    local = get_local_version()
    remote = get_remote_version()

    if not remote:
        print("⚠️ Не удалось проверить обновления.")
        return

    if local == remote:
        print(f"✅ У вас последняя версия: {local}")
        return

    print(f"🆕 Доступна новая версия {remote} (текущая {local})")
    download_update()
    install_update()

    with open(VERSION_FILE, "w", encoding="utf-8") as f:
        f.write(remote)

    restart_main()


if __name__ == "__main__":
    main()
