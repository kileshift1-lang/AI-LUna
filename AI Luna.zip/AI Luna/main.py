# main.py
# AI Luna — PyQt6 app with drag&drop image gallery, hover preview, and translations (optional)
# by Alik & ChatGPT

import sys
import re
import json
from pathlib import Path
from dataclasses import dataclass, asdict
from typing import List, Dict

from PyQt6 import QtCore
from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QTextEdit,
    QLabel, QScrollArea, QFrame, QSizePolicy, QComboBox, QMessageBox, QDialog,
    QFormLayout, QLineEdit, QFileDialog, QToolButton
)
from PyQt6.QtCore import (
    Qt, QPropertyAnimation, QEasingCurve, QTimer, pyqtSlot, QThread, pyqtSignal
)
from PyQt6.QtGui import QPalette, QColor, QCursor, QDesktopServices, QPixmap, QGuiApplication

# try import translator (optional)
try:
    from deep_translator import GoogleTranslator
    TRANSLATOR_AVAILABLE = True
except Exception:
    TRANSLATOR_AVAILABLE = False

SETTINGS_FILE = Path("settings.json")
MAX_SAVED_MESSAGES = 200
IMAGES_DIR = Path("images")

# -------------------------
# Utilities
# -------------------------
def load_settings() -> Dict:
    if SETTINGS_FILE.exists():
        try:
            with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}

def save_settings(d: Dict):
    try:
        with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print("Failed to save settings:", e)

def contains_cyrillic(s: str) -> bool:
    return bool(re.search(r"[А-Яа-яЁё]", s))

# -------------------------
# Data model
# -------------------------
@dataclass
class Message:
    role: str  # 'user' or 'assistant'
    content: str

# -------------------------
# Adapters & Worker Thread
# -------------------------
class ModelAdapter:
    def run(self, text: str, mode: str = "text", lang: str = "auto") -> str:
        raise NotImplementedError

class DummyAdapter(ModelAdapter):
    def run(self, text: str, mode: str = "text", lang: str = "auto") -> str:
        if mode == "text":
            return f"🧠 (dummy) AI Text generated for: {text}"
        elif mode == "image":
            return f"🖼️ (dummy) Generated image for: {text}"
        elif mode == "translate":
            return f"🌍 (dummy) {text[::-1]}"
        return text

class TranslatorAdapter(ModelAdapter):
    def __init__(self, target_lang: str = "auto"):
        self.target_lang = target_lang

    def set_target_lang(self, code: str):
        self.target_lang = code

    def run(self, text: str, mode: str = "translate", lang: str = "auto") -> str:
        if not text.strip():
            return "⚠️ " + ("Enter text to translate." if UIStrings.current_lang == "en" else "Введите текст для перевода.")
        if not TRANSLATOR_AVAILABLE:
            if UIStrings.current_lang == "en":
                return "❌ 'deep-translator' not installed. Install with: pip install deep-translator"
            else:
                return "❌ 'deep-translator' не установлен. Установите: pip install deep-translator"

        target = self.target_lang
        if target == "auto":
            target = "en" if contains_cyrillic(text) else "ru"

        try:
            translator = GoogleTranslator(source="auto", target=target)
            translated = translator.translate(text)
            if UIStrings.current_lang == "en":
                return f"🌍 Translation ({target}):\n{translated}"
            else:
                return f"🌍 Перевод ({target}):\n{translated}"
        except Exception as e:
            if UIStrings.current_lang == "en":
                return f"❌ Translation error: {e}"
            else:
                return f"❌ Ошибка перевода: {e}"

class InferenceThread(QThread):
    finished = pyqtSignal(str)
    error = pyqtSignal(str)

    def __init__(self, adapter: ModelAdapter, prompt: str, mode: str = "text", lang: str = "auto"):
        super().__init__()
        self.adapter = adapter
        self.prompt = prompt
        self.mode = mode
        self.lang = lang

    def run(self):
        try:
            res = self.adapter.run(self.prompt, mode=self.mode, lang=self.lang)
            self.finished.emit(res)
        except Exception as e:
            self.error.emit(str(e))

# -------------------------
# UI localization
# -------------------------
class UIStrings:
    current_lang = "ru"
    strings = {
        "ru": {
            "adapter": "Адаптер: {}",
            "ai_text": "🧠 AI Текст",
            "generate_image": "🎨 Генерировать картинки",
            "translate": "🌍 Перевод",
            "send": "Отправить",
            "translating": "⏳ Перевожу",
            "window_title": "AI Luna",
            "clear_confirm": "Очистить чат? Это действие нельзя отменить.",
            "clear_ok": "Чат очищен.",
            "empty_input": "Введите текст для отправки",
            "save_error": "Ошибка при сохранении настроек.",
            "settings_title": "Настройки",
            "reset_confirm": "Вы уверены, что хотите удалить все данные? (чат, настройки)",
            "reset_done": "Данные сброшены.",
            "version": "Версия: AI Luna",
            "lang_auto_en": "Авто → Английский (en)",
            "lang_auto_ru": "Авто → Русский (ru)",
            "lang_de": "Немецкий (de)",
            "lang_fr": "Французский (fr)",
            "lang_es": "Испанский (es)",
            "save_path": "Путь сохранения"
        },
        "en": {
            "adapter": "Adapter: {}",
            "ai_text": "🧠 AI Text",
            "generate_image": "🎨 Generate Images",
            "translate": "🌍 Translate",
            "send": "Send",
            "translating": "⏳ Translating",
            "window_title": "AI Luna",
            "clear_confirm": "Clear chat? This cannot be undone.",
            "clear_ok": "Chat cleared.",
            "empty_input": "Enter text to send",
            "save_error": "Error saving settings.",
            "settings_title": "Settings",
            "reset_confirm": "Are you sure you want to delete all data? (chat, settings)",
            "reset_done": "Data reset.",
            "version": "Version: AI Luna",
            "lang_auto_en": "Auto → English (en)",
            "lang_auto_ru": "Auto → Russian (ru)",
            "lang_de": "German (de)",
            "lang_fr": "French (fr)",
            "lang_es": "Spanish (es)",
            "save_path": "Save path"
        }
    }

    @classmethod
    def get(cls, key: str) -> str:
        return cls.strings[cls.current_lang].get(key, key)

# -------------------------
# Input override for Enter behavior
# -------------------------
class InputTextEdit(QTextEdit):
    def __init__(self, send_callback, *a, **k):
        super().__init__(*a, **k)
        self.send_callback = send_callback

    def keyPressEvent(self, e):
        if (e.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter)) and not (e.modifiers() & Qt.KeyboardModifier.ShiftModifier):
            e.accept()
            self.send_callback()
            return
        super().keyPressEvent(e)

# -------------------------
# Settings dialog
# -------------------------
class SettingsDialog(QDialog):
    def __init__(self, parent, app_ref):
        super().__init__(parent)
        self.app_ref = app_ref
        self.setWindowTitle(UIStrings.get("settings_title"))
        self.setModal(True)
        self.setFixedSize(420, 220)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)

        form = QFormLayout()
        save_label = UIStrings.get("save_path")
        self.save_folder_line = QLineEdit(self.app_ref.settings.get("save_path", ""))
        form.addRow(save_label, self.save_folder_line)

        version_label = QLabel(UIStrings.get("version"))
        form.addRow(version_label)

        layout.addLayout(form)

        # buttons
        btn_row = QHBoxLayout()
        self.reset_btn = QPushButton("Reset All" if UIStrings.current_lang == "en" else "Сбросить")
        self.reset_btn.clicked.connect(self._on_reset)
        self.browse_btn = QPushButton("Browse" if UIStrings.current_lang == "en" else "Обзор")
        self.browse_btn.clicked.connect(self._on_browse)
        self.close_btn = QPushButton("Close" if UIStrings.current_lang == "en" else "Закрыть")
        self.close_btn.clicked.connect(self.accept)
        btn_row.addWidget(self.browse_btn)
        btn_row.addWidget(self.reset_btn)
        btn_row.addStretch()
        btn_row.addWidget(self.close_btn)
        layout.addLayout(btn_row)

    def _on_browse(self):
        path = QFileDialog.getExistingDirectory(self, "Choose folder", str(Path.cwd()))
        if path:
            self.save_folder_line.setText(path)
            self.app_ref.settings["save_path"] = path
            save_settings(self.app_ref.settings)

    def _on_reset(self):
        reply = QMessageBox.question(self, UIStrings.get("settings_title"), UIStrings.get("reset_confirm"),
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            try:
                if SETTINGS_FILE.exists():
                    SETTINGS_FILE.unlink()
            except Exception as e:
                print("Could not remove settings file:", e)
            self.app_ref.reset_all_data()
            QMessageBox.information(self, UIStrings.get("settings_title"), UIStrings.get("reset_done"))
            self.accept()

# -------------------------
# Main App
# -------------------------
class AIApp(QWidget):
    def __init__(self):
        super().__init__()

        # enable drag & drop on window
        self.setAcceptDrops(True)

        # ensure images dir exists
        try:
            IMAGES_DIR.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass

        # load settings
        self.settings = load_settings()
        UIStrings.current_lang = self.settings.get("ui_lang", "ru")
        saved_target = self.settings.get("lang_code", "auto")
        self.theme = self.settings.get("theme", "dark")

        # separate histories per mode
        self.chat_histories: Dict[str, List[Message]] = {"text": [], "image": [], "translate": []}
        self.mode = "text"

        # fixed window
        self.setWindowTitle(UIStrings.get("window_title"))
        self.setFixedSize(1000, 700)

        self._animations = []
        self._spinner_step = 0
        self._spinner_timer = QTimer(self)
        self._spinner_timer.setInterval(350)
        self._spinner_timer.timeout.connect(self._advance_spinner)

        # adapters
        self.adapters = {
            "text": DummyAdapter(),
            "image": DummyAdapter(),
            "translate": TranslatorAdapter(target_lang=saved_target),
        }

        # load per-mode messages from settings
        self._load_messages_from_settings()
        self.messages = self.chat_histories[self.mode]

        # UI build
        self.init_ui()
        self.apply_theme()
        self.update_ui_texts()
        self._populate_messages_into_ui()

    def _load_messages_from_settings(self):
        chats = self.settings.get("chats", {})
        for mode in ("text", "image", "translate"):
            msg_list = chats.get(mode, [])
            self.chat_histories[mode] = [Message(**m) for m in msg_list][-MAX_SAVED_MESSAGES:]

    def _save_all_settings(self):
        try:
            self.chat_histories[self.mode] = self.messages
            self.settings["chats"] = {
                mode: [asdict(m) for m in msgs][-MAX_SAVED_MESSAGES:]
                for mode, msgs in self.chat_histories.items()
            }
            self.settings["lang_code"] = self.adapters["translate"].target_lang
            self.settings["ui_lang"] = UIStrings.current_lang
            self.settings["theme"] = self.theme
            save_settings(self.settings)
        except Exception as e:
            print("Save settings error:", e)
            QMessageBox.warning(self, UIStrings.get("window_title"), UIStrings.get("save_error"))

    def reset_all_data(self):
        self.chat_histories = {"text": [], "image": [], "translate": []}
        self.messages = self.chat_histories[self.mode]
        try:
            if SETTINGS_FILE.exists():
                SETTINGS_FILE.unlink()
        except Exception:
            pass
        self.settings = {}
        UIStrings.current_lang = "ru"
        self.adapters["translate"].set_target_lang("auto")
        self.theme = "dark"
        self.mode = "text"
        self._clear_chat_ui()
        self.ui_lang_box.setCurrentIndex(0)
        self.apply_theme()
        self.update_ui_texts()
        self._save_all_settings()

    def init_ui(self):
        main = QVBoxLayout(self)
        main.setContentsMargins(12, 12, 12, 12)
        main.setSpacing(8)

        top_row = QHBoxLayout()
        top_row.setSpacing(8)

        left_group = QHBoxLayout()
        # NOTE: swapped positions: gen_img first, then ai_text
        self.gen_img_btn = QPushButton()
        self.ai_text_btn = QPushButton()
        self.trans_btn = QPushButton()
        for btn in (self.gen_img_btn, self.ai_text_btn, self.trans_btn):
            btn.setCheckable(True)
            btn.clicked.connect(self.change_mode)
            btn.setFixedHeight(34)
        self.ai_text_btn.setChecked(True)

        self.clear_btn = QPushButton("🧹")
        self.clear_btn.setToolTip(UIStrings.get("clear_confirm"))
        self.clear_btn.setFixedSize(34, 34)
        self.clear_btn.clicked.connect(self._on_clear_chat)

        left_group.addWidget(self.gen_img_btn)
        left_group.addWidget(self.ai_text_btn)
        left_group.addWidget(self.trans_btn)
        left_group.addWidget(self.clear_btn)
        left_group.addStretch()

        top_row.addLayout(left_group)

        right_group = QHBoxLayout()
        right_group.setSpacing(6)

        self.ui_lang_box = QComboBox()
        self.ui_lang_box.addItems(["Русский", "English"])
        ui_lang = self.settings.get("ui_lang", "ru")
        self.ui_lang_box.setCurrentIndex(0 if ui_lang == "ru" else 1)
        self.ui_lang_box.currentIndexChanged.connect(self._ui_lang_changed)
        self.ui_lang_box.setFixedWidth(140)

        self.theme_btn = QPushButton()
        self.theme_btn.setFixedSize(38, 38)
        self.theme_btn.clicked.connect(self.toggle_theme)

        self.settings_btn = QToolButton()
        self.settings_btn.setText("⚙️")
        self.settings_btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.settings_btn.setToolTip(UIStrings.get("settings_title"))
        self.settings_btn.clicked.connect(self.open_settings_dialog)
        self.settings_btn.setFixedSize(36, 36)

        right_group.addWidget(self.ui_lang_box)
        right_group.addWidget(self.theme_btn)
        right_group.addWidget(self.settings_btn)

        top_row.addLayout(right_group)
        main.addLayout(top_row)

        # Lang selector for translator mode
        self.lang_selector = QComboBox()
        self.lang_selector_codes = ["auto", "en", "ru", "de", "fr", "es"]
        code_to_label = {
            "auto": UIStrings.get("lang_auto_en"),
            "en": UIStrings.get("lang_auto_en"),
            "ru": UIStrings.get("lang_auto_ru"),
            "de": UIStrings.get("lang_de"),
            "fr": UIStrings.get("lang_fr"),
            "es": UIStrings.get("lang_es"),
        }
        for c in self.lang_selector_codes:
            self.lang_selector.addItem(code_to_label.get(c, c))
        saved = self.settings.get("lang_code", "auto")
        try:
            idx = self.lang_selector_codes.index(saved)
        except ValueError:
            idx = 0
        self.lang_selector.setCurrentIndex(idx)
        self.lang_selector.currentIndexChanged.connect(self._lang_selector_changed)
        self.lang_selector.setVisible(False)
        main.addWidget(self.lang_selector)

        load_h = QHBoxLayout()
        load_h.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.loading_dots = QLabel("")
        self.loading_dots.setStyleSheet("color:#888; font-size:13px;")
        self.loading_text = QLabel("")
        self.loading_text.setStyleSheet("color:#888; font-size:13px;")
        load_h.addWidget(self.loading_dots)
        load_h.addSpacing(6)
        load_h.addWidget(self.loading_text)
        self.loading_container = QFrame()
        self.loading_container.setLayout(load_h)
        self.loading_container.setVisible(False)
        main.addWidget(self.loading_container)

        # Chat area
        self.chat_area = QScrollArea()
        self.chat_area.setWidgetResizable(True)
        self.chat_content = QWidget()
        self.chat_layout = QVBoxLayout(self.chat_content)
        self.chat_layout.addStretch()
        self.chat_area.setWidget(self.chat_content)
        main.addWidget(self.chat_area, 1)

        # Input area
        h = QHBoxLayout()
        self.input_edit = InputTextEdit(self._on_enter_send)
        self.input_edit.setFixedHeight(110)
        self.send_btn = QPushButton()
        self.send_btn.clicked.connect(self._on_send_clicked)
        self.send_btn.setFixedHeight(40)
        h.addWidget(self.input_edit)
        h.addWidget(self.send_btn)
        main.addLayout(h)

    def update_ui_texts(self):
        self.gen_img_btn.setText(UIStrings.get("generate_image"))
        self.ai_text_btn.setText(UIStrings.get("ai_text"))
        self.trans_btn.setText(UIStrings.get("translate"))
        self.send_btn.setText(UIStrings.get("send"))
        self.loading_text.setText(UIStrings.get("translating"))
        self.theme_btn.setText("☀️" if self.theme == "light" else "🌙")

        self.lang_selector.blockSignals(True)
        self.lang_selector.clear()
        code_to_label = {
            "auto": UIStrings.get("lang_auto_en"),
            "en": UIStrings.get("lang_auto_en"),
            "ru": UIStrings.get("lang_auto_ru"),
            "de": UIStrings.get("lang_de"),
            "fr": UIStrings.get("lang_fr"),
            "es": UIStrings.get("lang_es"),
        }
        for c in self.lang_selector_codes:
            self.lang_selector.addItem(code_to_label.get(c, c))
        self.lang_selector.blockSignals(False)

    def apply_theme(self):
        palette = QPalette()
        if self.theme == "dark":
            palette.setColor(QPalette.ColorRole.Window, QColor(30, 30, 30))
            palette.setColor(QPalette.ColorRole.WindowText, Qt.GlobalColor.white)
            palette.setColor(QPalette.ColorRole.Base, QColor(45, 45, 45))
            palette.setColor(QPalette.ColorRole.Text, Qt.GlobalColor.white)
        else:
            palette.setColor(QPalette.ColorRole.Window, QColor(245, 245, 245))
            palette.setColor(QPalette.ColorRole.WindowText, Qt.GlobalColor.black)
            palette.setColor(QPalette.ColorRole.Base, QColor(255, 255, 255))
            palette.setColor(QPalette.ColorRole.Text, Qt.GlobalColor.black)
        self.setPalette(palette)

    def toggle_theme(self):
        self.theme = "light" if self.theme == "dark" else "dark"
        self.settings["theme"] = self.theme
        save_settings(self.settings)
        anim = QPropertyAnimation(self, b"windowOpacity")
        anim.setDuration(320)
        anim.setStartValue(0.35)
        anim.setEndValue(1.0)
        anim.setEasingCurve(QEasingCurve.Type.InOutCubic)
        anim.start()
        self._animations.append(anim)
        self.apply_theme()
        self.update_ui_texts()

    def change_mode(self):
        sender = self.sender()
        for btn in (self.gen_img_btn, self.ai_text_btn, self.trans_btn):
            btn.setChecked(False)
        sender.setChecked(True)

        if sender == self.ai_text_btn:
            self.mode = "text"
        elif sender == self.gen_img_btn:
            self.mode = "image"
        else:
            self.mode = "translate"

        self.lang_selector.setVisible(self.mode == "translate")
        self._clear_chat_ui()
        self.chat_histories[self.mode] = self.chat_histories.get(self.mode, [])
        self.messages = self.chat_histories[self.mode]
        self._populate_messages_into_ui()
        self.update_ui_texts()

    def _lang_selector_changed(self, idx: int):
        if idx < 0 or idx >= len(self.lang_selector_codes):
            code = "auto"
        else:
            code = self.lang_selector_codes[idx]
        self.adapters["translate"].set_target_lang(code)
        self.settings["lang_code"] = code
        save_settings(self.settings)

    def _ui_lang_changed(self, idx: int):
        UIStrings.current_lang = "ru" if idx == 0 else "en"
        self.settings["ui_lang"] = UIStrings.current_lang
        save_settings(self.settings)
        self.update_ui_texts()

    def _advance_spinner(self):
        self._spinner_step = (self._spinner_step + 1) % 4
        dots = "." * self._spinner_step
        self.loading_dots.setText(dots)
        self.loading_text.setText(UIStrings.get("translating"))

    def show_loading(self, on: bool):
        self.loading_container.setVisible(on)
        if on:
            self._spinner_step = 0
            self.loading_dots.setText("")
            self.loading_text.setText(UIStrings.get("translating"))
            self._spinner_timer.start()
        else:
            self._spinner_timer.stop()
            anim = QPropertyAnimation(self.loading_container, b"windowOpacity")
            anim.setDuration(250)
            anim.setStartValue(1.0)
            anim.setEndValue(0.0)
            anim.start()
            self._animations.append(anim)
            QTimer.singleShot(260, lambda: self.loading_container.setVisible(False))
            self.loading_container.setWindowOpacity(1.0)

    @pyqtSlot()
    def _on_enter_send(self):
        self._on_send_clicked()

    def _on_send_clicked(self):
        text = self.input_edit.toPlainText().strip()
        if not text:
            QMessageBox.information(self, UIStrings.get("window_title"), UIStrings.get("empty_input"))
            return
        self._append_message_local("user", text)
        self.input_edit.clear()
        self.show_loading(True)

        adapter = None
        if self.mode == "translate":
            adapter = self.adapters["translate"]
        elif self.mode == "image":
            adapter = self.adapters["image"]
        else:
            adapter = self.adapters["text"]

        lang = self.settings.get("lang_code", "auto")
        self._current_thread = InferenceThread(adapter, text, mode=self.mode, lang=lang)
        self._current_thread.finished.connect(self._on_inference_finished)
        self._current_thread.error.connect(self._on_inference_error)
        self._current_thread.start()

    def _on_inference_finished(self, result: str):
        display = result
        if not any(result.startswith(p) for p in ("🤖", "🌍", "🖼️", "🧠", "❌")):
            display = f"🤖 {result}"
        self._append_message_local("assistant", display)
        self.show_loading(False)
        self._save_all_settings()

    def _on_inference_error(self, err: str):
        self._append_message_local("assistant", f"❌ {err}")
        self.show_loading(False)
        self._save_all_settings()

    def _append_message_local(self, role: str, text: str):
        m = Message(role=role, content=text)
        self.messages.append(m)
        if len(self.messages) > MAX_SAVED_MESSAGES:
            self.messages = self.messages[-MAX_SAVED_MESSAGES:]
            self.chat_histories[self.mode] = self.messages
        self._add_message_widget(text, align_right=(role == "user"))
        self._save_all_settings()

    def _add_message_widget(self, text: str, align_right: bool = False):
        bubble = QFrame()
        bubble_layout = QHBoxLayout(bubble)
        bubble_layout.setContentsMargins(8, 6, 8, 6)
        bubble_layout.setSpacing(8)

        label = QLabel(text)
        label.setWordWrap(True)
        bg = "#2e2e2e" if self.theme == "dark" else "#e0e0e0"
        fg = "white" if self.theme == "dark" else "black"
        label.setStyleSheet(f"background-color: {bg}; border-radius:12px; padding:10px; color:{fg}; font-size:14px;")
        label.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        is_translate_result = False
        if not align_right and ("🌍" in text or "Перевод" in text or "Translation" in text):
            is_translate_result = True

        copy_btn = None
        if is_translate_result:
            copy_btn = QToolButton()
            copy_btn.setText("📋")
            copy_btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
            copy_btn.setAutoRaise(True)
            copy_btn.setToolTip("Copy translation" if UIStrings.current_lang == "en" else "Копировать перевод")
            def on_copy():
                clip = QApplication.clipboard()
                if "\n" in text:
                    to_copy = text.split("\n", 1)[1]
                else:
                    to_copy = re.sub(r"^[\W_]*", "", text)
                clip.setText(to_copy)
                old_tt = copy_btn.toolTip()
                copy_btn.setToolTip("Copied ✅" if UIStrings.current_lang == "en" else "Скопировано ✅")
                QTimer.singleShot(900, lambda: copy_btn.setToolTip(old_tt))
            copy_btn.clicked.connect(on_copy)

        container = QHBoxLayout()
        container.setContentsMargins(0,0,0,0)
        container.setSpacing(6)
        if align_right:
            if self.mode == "translate":
                icon_label = QLabel("🗣️")
                icon_label.setStyleSheet("font-size:16px; margin-left:6px;")
                container.addStretch()
                container.addWidget(label)
                container.addWidget(icon_label)
            else:
                container.addStretch()
                container.addWidget(label)
        else:
            container.addWidget(label)
            if copy_btn:
                container.addWidget(copy_btn)
            container.addStretch()

        wrapper = QFrame()
        wrapper.setLayout(container)

        outer = QHBoxLayout()
        outer.setContentsMargins(0,0,0,0)
        outer.setSpacing(0)
        if align_right:
            outer.addStretch()
            outer.addWidget(wrapper)
        else:
            outer.addWidget(wrapper)
            outer.addStretch()

        frame = QFrame()
        frame.setLayout(outer)
        self.chat_layout.insertWidget(self.chat_layout.count() - 1, frame)

        frame.setWindowOpacity(0.0)
        anim = QPropertyAnimation(frame, b"windowOpacity")
        anim.setDuration(300)
        anim.setStartValue(0.0)
        anim.setEndValue(1.0)
        anim.setEasingCurve(QEasingCurve.Type.InOutCubic)
        anim.start()
        self._animations.append(anim)

        QTimer.singleShot(80, lambda: self.chat_area.verticalScrollBar().setValue(self.chat_area.verticalScrollBar().maximum()))

    def _populate_messages_into_ui(self):
        for m in self.messages:
            self._add_message_widget(m.content, align_right=(m.role == "user"))

    def _clear_chat_ui(self):
        while self.chat_layout.count() > 1:
            item = self.chat_layout.takeAt(0)
            if item:
                w = item.widget()
                if w:
                    w.deleteLater()

    def _on_clear_chat(self):
        reply = QMessageBox.question(self, UIStrings.get("window_title"), UIStrings.get("clear_confirm"),
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            self.messages.clear()
            self.chat_histories[self.mode] = self.messages
            self._clear_chat_ui()
            self._save_all_settings()
            QMessageBox.information(self, UIStrings.get("window_title"), UIStrings.get("clear_ok"))

    def open_settings_dialog(self):
        dlg = SettingsDialog(self, self)
        dlg.exec()

    def closeEvent(self, event):
        self.chat_histories[self.mode] = self.messages
        self._save_all_settings()
        event.accept()

    # -------------------------
    # Drag & Drop
    # -------------------------
    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls() or event.mimeData().hasText():
            event.acceptProposedAction()
        else:
            event.ignore()

    def dragMoveEvent(self, event):
        event.acceptProposedAction()

    def dropEvent(self, event):
        """Обработка перетаскивания файлов и текста"""
        if event.mimeData().hasUrls():
            paths = [url.toLocalFile() for url in event.mimeData().urls()]
            image_paths = []
            text_paths = []

            for path in paths:
                if not path:
                    continue
                p = Path(path)
                if p.suffix.lower() == ".txt":
                    text_paths.append(path)
                elif p.suffix.lower() in (".png", ".jpg", ".jpeg", ".webp"):
                    image_paths.append(path)
                else:
                    QMessageBox.warning(self, "❌", f"Тип файла не поддерживается:\n{p.name}")

            # Покажем все изображения в сетке
            if image_paths:
                self._add_images_grid_to_chat(image_paths)

            # Загрузим первый текстовый файл
            if text_paths:
                self._load_text_file(text_paths[0])

        elif event.mimeData().hasText():
            text = event.mimeData().text().strip()
            self.input_edit.setPlainText(text[:5000])
            QMessageBox.information(self, "📋", "Текст вставлен из буфера или перетаскивания.")

        event.acceptProposedAction()

    # -------------------------
    # Helpers for drag-drop
    # -------------------------
    def _load_text_file(self, path: str):
        """Загрузка текста из txt-файла"""
        try:
            with open(path, "r", encoding="utf-8") as f:
                content = f.read().strip()
                self.input_edit.setPlainText(content[:5000])
            QMessageBox.information(self, "✅", f"Текст из файла '{Path(path).name}' вставлен в поле ввода.")
        except Exception as e:
            QMessageBox.warning(self, "Ошибка", f"Не удалось прочитать файл:\n{e}")

    def _add_images_grid_to_chat(self, paths: List[str]):
        """Отображение изображений в сетке с подписями, кнопкой 'Открыть все' и всплывающим превью (fade-in)"""
        from PyQt6.QtWidgets import QLabel, QGridLayout, QPushButton, QVBoxLayout, QWidget
        from PyQt6.QtGui import QPixmap, QGuiApplication

        frame = QFrame()
        frame.setStyleSheet("""
            QFrame {
                background: #f7f7f7;
                border-radius: 12px;
                padding: 8px;
                margin: 8px 0;
            }
        """)

        vbox = QVBoxLayout(frame)
        vbox.setSpacing(10)
        vbox.setContentsMargins(8, 8, 8, 8)

        grid = QGridLayout()
        grid.setSpacing(10)
        cols = 3
        row, col = 0, 0

        # preview popup (single widget reused)
        preview_popup = QLabel(None, Qt.WindowType.ToolTip)
        preview_popup.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        preview_popup.setStyleSheet("""
            QLabel {
                border: 2px solid rgba(0,0,0,0.25);
                border-radius: 8px;
                background: #ffffff;
                padding: 4px;
            }
        """)
        preview_popup.setWindowFlag(Qt.WindowType.FramelessWindowHint, True)
        preview_popup.setWindowOpacity(0.0)
        preview_anim = QPropertyAnimation(preview_popup, b"windowOpacity")
        preview_anim.setDuration(180)
        preview_anim.setStartValue(0.0)
        preview_anim.setEndValue(1.0)
        preview_anim.setEasingCurve(QEasingCurve.Type.InOutCubic)
        preview_popup.hide()

        for path in paths:
            pix = QPixmap(path)
            if pix.isNull():
                continue

            max_width = 180
            pixmap_small = pix.scaledToWidth(max_width, Qt.TransformationMode.SmoothTransformation)

            item_widget = QWidget()
            item_layout = QVBoxLayout(item_widget)
            item_layout.setSpacing(6)
            item_layout.setContentsMargins(0, 0, 0, 0)

            img_label = QLabel()
            img_label.setPixmap(pixmap_small)
            img_label.setScaledContents(False)
            img_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            img_label.setStyleSheet("""
                QLabel {
                    border-radius: 10px;
                    background: white;
                    padding: 3px;
                    border: 1px solid #ddd;
                }
                QLabel:hover {
                    border: 1px solid #aaa;
                }
            """)
            img_label.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))

            # подпись
            name_label = QLabel(Path(path).name)
            name_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            name_label.setStyleSheet("color: #555; font-size: 11px; max-width: 160px;")
            name_label.setWordWrap(False)
            name_label.setToolTip(Path(path).name)
            elided = name_label.fontMetrics().elidedText(Path(path).name, Qt.TextElideMode.ElideRight, 160)
            name_label.setText(elided)

            # show/hide preview handlers
            def show_preview(ev, path=path):
                pix_large = QPixmap(path)
                if pix_large.isNull():
                    return
                max_prev = 420
                pixp = pix_large.scaledToWidth(max_prev, Qt.TransformationMode.SmoothTransformation)
                preview_popup.setPixmap(pixp)
                preview_popup.adjustSize()
                # position near cursor but within screen
                gp = QCursor.pos()
                screen_geom = QGuiApplication.primaryScreen().availableGeometry()
                x = gp.x() + 20
                y = gp.y() + 20
                # ensure not out of screen
                if x + preview_popup.width() > screen_geom.right():
                    x = gp.x() - preview_popup.width() - 20
                if y + preview_popup.height() > screen_geom.bottom():
                    y = gp.y() - preview_popup.height() - 20
                preview_popup.move(x, y)
                preview_popup.show()
                preview_anim.stop()
                preview_anim.setDirection(QPropertyAnimation.Direction.Forward)
                preview_anim.start()

            def move_preview(ev):
                if not preview_popup.isVisible():
                    return
                gp = QCursor.pos()
                x = gp.x() + 20
                y = gp.y() + 20
                screen_geom = QGuiApplication.primaryScreen().availableGeometry()
                if x + preview_popup.width() > screen_geom.right():
                    x = gp.x() - preview_popup.width() - 20
                if y + preview_popup.height() > screen_geom.bottom():
                    y = gp.y() - preview_popup.height() - 20
                preview_popup.move(x, y)

            def hide_preview(ev):
                if preview_popup.isVisible():
                    preview_anim.stop()
                    preview_anim.setDirection(QPropertyAnimation.Direction.Backward)
                    preview_anim.start()
                    QTimer.singleShot(preview_anim.duration() + 20, lambda: preview_popup.hide())

            img_label.enterEvent = lambda e, path=path: show_preview(e, path)
            img_label.mouseMoveEvent = lambda e: move_preview(e)
            img_label.leaveEvent = lambda e: hide_preview(e)

            # open on click
            def open_image(path=path):
                QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(path))
            img_label.mousePressEvent = lambda e, path=path: open_image(path)

            item_layout.addWidget(img_label)
            item_layout.addWidget(name_label)

            grid.addWidget(item_widget, row, col)
            col += 1
            if col >= cols:
                col = 0
                row += 1

        vbox.addLayout(grid)

        # "Open all" button
        btn_open_all = QPushButton("Открыть все" if UIStrings.current_lang == "ru" else "Open all")
        btn_open_all.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        btn_open_all.setFixedHeight(34)
        btn_open_all.setStyleSheet("""
            QPushButton {
                background-color: #e8e8e8;
                border-radius: 8px;
                padding: 6px 14px;
                font-weight: 500;
            }
            QPushButton:hover {
                background-color: #dcdcdc;
            }
        """)

        def open_all():
            folder = str(Path(paths[0]).parent)
            QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(folder))

        btn_open_all.clicked.connect(open_all)
        vbox.addWidget(btn_open_all, alignment=Qt.AlignmentFlag.AlignCenter)

        self.chat_layout.insertWidget(self.chat_layout.count() - 1, frame)

        # fade-in animation for the frame
        frame.setWindowOpacity(0.0)
        anim = QPropertyAnimation(frame, b"windowOpacity")
        anim.setDuration(340)
        anim.setStartValue(0.0)
        anim.setEndValue(1.0)
        anim.setEasingCurve(QEasingCurve.Type.InOutCubic)
        anim.start()
        self._animations.append(anim)

        # auto-scroll down
        QTimer.singleShot(120, lambda: self.chat_area.verticalScrollBar().setValue(
            self.chat_area.verticalScrollBar().maximum()
        ))

        # save to history
        self._append_message_local("user", f"🖼️ Загружено {len(paths)} изображений")

    def run(self):
        self.show()

# -------------------------
# Entrypoint
# -------------------------
def main():
    settings = load_settings()
    UIStrings.current_lang = settings.get("ui_lang", "ru")
    app = QApplication(sys.argv)
    window = AIApp()
    window.run()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
